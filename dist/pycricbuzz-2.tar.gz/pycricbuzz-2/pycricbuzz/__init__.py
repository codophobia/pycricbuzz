"""
cricbuzz
"""

__title__ = 'cricbuzz'
__version__ = '0.1'
__author__ = 'Shivam Mitra'
__license__ = 'GPLv2'

from .cricbuzz import Cricbuzz